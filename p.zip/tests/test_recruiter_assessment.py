"""Recruiter Assessment (eval-prompt/2.0) + canonical 1.1 tests.

Covers: RA schema validation (valid / missing / null / bad types),
the deterministic evidence rules (evidence-less points dropped;
unevidenced 'verified' gaps demoted to unmentioned areas),
historical-payload compatibility, prompt content, prompt-version
recording, and the canonical ai-evaluation/1.1 mapping.
"""

from __future__ import annotations

import copy
import json

import pytest

from candidate_intelligence import build_canonical, check_canonical
from evaluation import prompt as eval_prompt
from evaluation.schema import validate_evaluation


def _payload(**overrides):
    payload = {
        "candidate": {"name": "Asha Verma", "headline": "Backend Dev",
                      "location": "Mumbai", "email": "a@x.com",
                      "summary": "Backend developer."},
        "career_stage": "Experienced Professional",
        "professional_domain": "Software Engineering",
        "matching_sections": [],
        "missing_sections": [],
        "good_to_have": [],
        "completeness": {"score": 80, "classification": "Good",
                         "explanation": {"why_low": "x"}},
        "quality": {"score": 70, "classification": "Good",
                    "explanation": {"why_low": "y"}},
        "role_suitability": [
            {"role": "Backend Developer", "score": 88,
             "matching_skills": ["Python"], "missing_skills": ["Docker"],
             "relevant_projects": [], "relevant_experience": [],
             "evidence": [], "explanation": ""}],
        "suitable_roles": ["Backend Developer"],
        "strengths": [], "weaknesses": [], "recommendations": [],
        "recruiter_assessment": {
            "summary": "Backend developer with evidenced API work.",
            "strengths": [{"point": "Deep API experience",
                           "evidence": ["Built APIs for 40 clients"]}],
            "limitations": [{"point": "No quantified outcomes",
                             "evidence": ["No metrics in any bullet"]}],
            "assessment_insights": [
                {"point": "Skills corroborated by project work",
                 "evidence": ["FastAPI in skills and projects"]}],
            "verified_skill_gaps": [
                {"skill_or_area": "API testing",
                 "basis": "Claims API expertise; no testing practice "
                          "evidenced anywhere in described work",
                 "evidence": ["Experience bullets list no tests"]}],
            "unmentioned_areas": [
                {"area": "Docker",
                 "relevance_note": "Preferred for Backend Developer; "
                                   "simply not mentioned."}],
            "verification_points": ["Confirm personal contribution "
                                    "to the billing API"],
            "information_completeness_note": "Assessor has core "
                                             "history; outcomes are "
                                             "unverifiable from the "
                                             "document.",
            "data_reliability_note": "Claims are consistent but "
                                     "lightly evidenced; verify "
                                     "scale claims.",
        },
    }
    payload.update(overrides)
    return payload


def _validate(payload):
    return validate_evaluation(json.dumps(payload))


# --- schema validation ----------------------------------------------------
def test_valid_recruiter_assessment_passes():
    result, error = _validate(_payload())
    assert error is None, error
    ra = result["recruiter_assessment"]
    assert ra["summary"].startswith("Backend developer")
    assert ra["verified_skill_gaps"][0]["skill_or_area"] == "API testing"
    assert ra["unmentioned_areas"][0]["area"] == "Docker"


def test_historical_payload_without_ra_still_validates():
    payload = _payload()
    del payload["recruiter_assessment"]
    payload["recommendations"] = ["Add Docker experience"]
    result, error = _validate(payload)
    assert error is None
    assert result["recruiter_assessment"] is None
    assert result["recommendations"] == ["Add Docker experience"]


def test_ra_null_and_bad_types_are_repaired_or_rejected_safely():
    payload = _payload()
    payload["recruiter_assessment"]["strengths"] = [
        {"point": "X", "evidence": "not-a-list"}]
    result, error = _validate(payload)
    # lenient coercion turns the bare evidence string into a list
    assert error is None
    assert result["recruiter_assessment"]["strengths"][0][
        "evidence"] == ["not-a-list"]


# --- evidence rules ---------------------------------------------------------
def test_evidenceless_points_are_dropped():
    payload = _payload()
    payload["recruiter_assessment"]["strengths"] = [
        {"point": "Great communicator", "evidence": []},
        {"point": "Deep API experience",
         "evidence": ["Built APIs for 40 clients"]}]
    payload["recruiter_assessment"]["limitations"] = [
        {"point": "Vague concern", "evidence": []}]
    result, error = _validate(payload)
    assert error is None
    ra = result["recruiter_assessment"]
    assert [s["point"] for s in ra["strengths"]] == [
        "Deep API experience"]
    assert ra["limitations"] == []


def test_unevidenced_gap_is_demoted_never_stored_as_verified():
    payload = _payload()
    payload["recruiter_assessment"]["verified_skill_gaps"] = [
        {"skill_or_area": "Kubernetes", "basis": "",
         "evidence": []}]
    payload["recruiter_assessment"]["unmentioned_areas"] = []
    result, error = _validate(payload)
    assert error is None
    ra = result["recruiter_assessment"]
    assert ra["verified_skill_gaps"] == []
    assert ra["unmentioned_areas"][0]["area"] == "Kubernetes"
    assert "not evidence of absence" in ra["unmentioned_areas"][0][
        "relevance_note"]


def test_role_missing_skill_is_not_a_verified_gap():
    # Docker sits in role_suitability.missing_skills AND
    # unmentioned_areas in the fixture — and nowhere else.
    result, _ = _validate(_payload())
    gaps = [g["skill_or_area"] for g in
            result["recruiter_assessment"]["verified_skill_gaps"]]
    assert "Docker" not in gaps


# --- prompt -------------------------------------------------------------------
def test_prompt_is_recruiter_facing_and_versioned():
    text = eval_prompt.build_instructions()
    assert eval_prompt.PROMPT_VERSION == "eval-prompt/2.0"
    assert "RECRUITER ASSESSMENT" in text
    assert "CANDIDATE INFORMATION COMPLETENESS" in text
    assert "RESUME DATA RELIABILITY" in text
    assert "Leave EMPTY: top-level recommendations" in text
    assert "absence of evidence" in text


# --- canonical 1.1 --------------------------------------------------------------
def _record_with_ra():
    result, error = _validate(_payload())
    assert error is None
    entry = {"analysis_id": "ra-1", "status": "success",
             "analysis_version": 1, "model": "m",
             "created_at": "2026-11-12T00:00:00+00:00",
             "evaluation": result, "error": None}
    return {"resume_id": "ra-test-00000001", "filename": "a.pdf",
            "resume_json": {"full_name": "Asha Verma",
                            "skills": {"technical_skills": ["Python"]},
                            "experience": [], "education": [],
                            "certifications": []},
            "analyses": [entry], "analysis": entry}


def test_canonical_11_carries_recruiter_assessment():
    doc = build_canonical(_record_with_ra())
    ok, model = check_canonical(doc)
    assert ok, model
    assert doc["metadata"]["schema_version"] == "ai-evaluation/1.1"
    ra = doc["recruiter_assessment"]
    assert ra["summary"].startswith("Backend developer")
    assert ra["verified_skill_gaps"][0]["skill_or_area"] == \
        "API testing"
    # canonical strengths now carry the RA evidence
    assert doc["candidate_evaluation"]["strengths"][0]["evidence"] == [
        "Built APIs for 40 clients"]
    # verified gap also surfaces in gaps with its source labelled
    assert any(g.get("source") == "recruiter_assessment"
               for g in doc["gaps"]["detected_skill_gaps"])
    # unmentioned Docker is unverified info, not a gap
    assert "Docker" in doc["gaps"]["unverified_information"]


def test_canonical_historical_evaluation_has_null_ra():
    record = _record_with_ra()
    record["analysis"]["evaluation"] = dict(
        record["analysis"]["evaluation"])
    record["analysis"]["evaluation"]["recruiter_assessment"] = None
    record["analyses"] = [record["analysis"]]
    doc = build_canonical(record)
    ok, _ = check_canonical(doc)
    assert ok
    assert doc["recruiter_assessment"] is None
